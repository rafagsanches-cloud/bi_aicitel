# Montagem do painel no Power BI

Este guia monta no Power BI Desktop o mesmo painel da versão em Streamlit. Os dados já chegam limpos e tratados pelo `preparar_dados.py`; aqui o trabalho é importar, relacionar as tabelas, criar as medidas e desenhar as páginas. Leva cerca de uma hora.

O arquivo `.pbix` não acompanha o pacote porque ele só pode ser gerado dentro do Power BI Desktop. Tudo o que ele precisa (dados, consultas, medidas e tema) está nesta pasta.

## Arquivos desta pasta

| Arquivo | Conteúdo |
| --- | --- |
| `fato_empresas.csv` | 188.353 estabelecimentos ativos da Vila Olímpia e entorno e dos demais bairros da Zona Sul |
| `dim_atividade.csv` | As 71 atividades (CNAE), com nome curto, segmento e totais do município |
| `oportunidades.csv` | Ranking de oportunidades já calculado para duas áreas, com os pesos padrão |
| `consultas_power_query.m` | Código das três consultas do Power Query |
| `medidas.dax` | Medidas DAX do painel |
| `tema_aicitel.json` | Cores e fontes do painel |

## 1. Importar os dados

1. Abra o Power BI Desktop e vá em **Página Inicial > Transformar dados**.
2. Em **Gerenciar parâmetros > Novo parâmetro**, crie `PastaDados` do tipo Texto. No valor, coloque o caminho desta pasta terminando com barra invertida, por exemplo `C:\Aicitel\powerbi\`.
3. Para cada tabela, use **Nova fonte > Consulta nula**, abra o **Editor Avançado** e cole o bloco correspondente de `consultas_power_query.m`. Dê às consultas os nomes `Empresas`, `Atividades` e `Oportunidades`.
4. Clique em **Fechar e aplicar**.

Se preferir não usar o parâmetro, dá para importar cada CSV por **Obter dados > Texto/CSV**, escolhendo origem UTF-8 e delimitador ponto e vírgula. Nesse caso, confira se `cnae_cod` ficou como texto, porque o Power BI tende a convertê-lo em número.

## 2. Relacionamento e medidas

Na exibição de **Modelo**, ligue `Empresas[cnae_cod]` a `Atividades[cnae_cod]` (muitos para um, filtro em direção única). A tabela `Oportunidades` fica solta, sem relacionamento.

Crie uma tabela vazia chamada `Medidas` (**Página Inicial > Inserir dados > Carregar**) e adicione cada medida de `medidas.dax` com **Nova medida**. Formate `Variação 12 meses %` e `% no bairro` como porcentagem, e as contagens como número inteiro com separador de milhar.

Para aplicar o tema: **Exibição > Temas > Procurar temas** e escolha `tema_aicitel.json`.

## 3. Páginas do relatório

Coloque no topo de todas as páginas as segmentações de `Empresas[regiao]` e `Atividades[segmento]`, e uma caixa de texto com a medida `Texto da data de referência`. Use a segmentação de segmento a partir da tabela `Atividades`. Se ela vier da tabela `Empresas`, a contagem de escritórios concorrentes some quando um segmento é escolhido.

### Página 1 - Visão geral

- Quatro **cartões**: `Empresas ativas`, `Abertas 12 meses`, `Escritórios de contabilidade` e `Empresas por escritório`.
- **Gráfico de barras clusterizado** (horizontal): eixo Y `Atividades[segmento]`, eixo X `Empresas ativas`, classificado do maior para o menor. Uma cor só.
- **Gráfico de linhas** com as empresas abertas por mês: eixo X `Empresas[data_inicio]` na hierarquia Ano > Mês, valor `Empresas ativas`. Filtre a data de 01/09/2023 a 31/08/2026, os últimos 36 meses completos da base.
- **Tabela**: `Atividades[atividade_resumo]`, `Empresas ativas` e `Abertas 12 meses`, com filtro Top N = 15 por `Empresas ativas`.

### Página 2 - Segmentos em crescimento

- **Gráfico de barras** horizontal: eixo Y `Atividades[segmento]`, eixo X `Diferença para a média (p.p.)`, classificado do maior para o menor. Em **Colunas > Cor > fx**, escolha "Valor do campo" e a medida `Cor do crescimento`. Barras azuis crescem acima da média da área; vermelhas, abaixo.
- **Matriz**: linhas `Atividades[segmento]`; valores `Empresas ativas`, `Abertas 12 meses`, `Abertas 12 meses anteriores`, `Variação 12 meses %` e `Diferença para a média (p.p.)`.
- **Gráfico de áreas** com pequenos múltiplos: eixo X `Empresas[ano]`, valor `Empresas ativas`, **Pequenos múltiplos** `Atividades[segmento]`, filtro de ano entre 2016 e 2025. Em **Pequenos múltiplos > Layout**, ative escala Y independente.

### Página 3 - Oportunidades

- **Segmentação** de `Oportunidades[area]` com seleção única (substitui a de região nesta página).
- **Gráfico de barras** horizontal: eixo Y `Oportunidades[atividade_resumo]`, eixo X `Oportunidades[indice]` (soma), filtro Top N = 15 por índice, eixo X fixo de 0 a 100.
- **Tabela** do ranking: `posicao`, `atividade_resumo`, `segmento`, `volume`, `novas`, `crescimento`, `especializacao` e `indice`. Em `indice`, aplique barras de dados.
- **Tabela** de prospecção: `Empresas[cnpj]`, `nome_fantasia`, `atividade_resumo`, `bairro`, `cep` e `data_inicio`, com filtros de visual `recente_12m = 1`, `concorrente = 0` e `matriz_filial = Matriz`. Ordene por `data_inicio`, da mais recente para a mais antiga.

O ranking do Power BI usa os pesos padrão (30% quantidade, 30% empresas novas, 20% crescimento e 20% especialização). Para testar outros pesos, use a versão em Streamlit, que recalcula na hora.

### Página 4 - Bairros e concorrência

- **Gráfico de barras** horizontal: eixo Y `Empresas[bairro]`, eixo X `Empresas ativas`, Top N = 15.
- **Tabela**: `Empresas[bairro]`, `Empresas ativas`, `Escritórios de contabilidade` e `Empresas por escritório`, com filtro de visual `Empresas ativas` maior ou igual a 100, ordenada por `Empresas por escritório`.
- **Matriz** como mapa de calor: linhas `Atividades[segmento]`, colunas `Empresas[bairro]` (Top N = 12 por `Empresas ativas`), valor `% no bairro`. Em **Elementos da célula**, ative a cor de fundo com escala de três cores do tema (azul claro ao azul escuro).

### Página 5 - Dados e método

Caixas de texto com a fonte dos dados, as etapas de tratamento e as limitações. O texto pode ser copiado da aba "Dados e método" do painel em Streamlit ou do `README.md`.

## 4. Conferência dos números

Com todos os segmentos selecionados, as medidas devem bater com a versão em Streamlit:

| Região | Empresas ativas | Abertas 12 meses | Abertas 12 meses anteriores | Escritórios | Empresas por escritório |
| --- | --- | --- | --- | --- | --- |
| Vila Olímpia e entorno | 10.276 | 1.127 | 968 | 170 | 60 |
| As duas regiões juntas (Zona Sul inteira) | 179.349 | 30.991 | 26.956 | 2.723 | 66 |

Se algum valor divergir, os suspeitos mais comuns são a coluna `cnae_cod` importada como número ou a segmentação de segmento vinda da tabela errada.

## 5. Publicar e entregar

**No Power BI Service.** Salve o `.pbix` e use **Página Inicial > Publicar**, entrando com uma conta corporativa ou institucional (o e-mail da faculdade costuma servir; contas pessoais do Outlook ou Gmail não são aceitas). Depois de publicado, o relatório pode ser compartilhado com o professor pelo botão **Compartilhar**.

**Link público.** Se a conta permitir, **Arquivo > Inserir relatório > Publicar na Web** gera um link aberto. Os dados do painel são públicos (CNPJ), mas lembre que qualquer pessoa com o link verá o relatório.

**Entrega em arquivo.** Para anexar no ambiente da disciplina, entregue o `.pbix` e um PDF gerado em **Arquivo > Exportar > Exportar para PDF**.
