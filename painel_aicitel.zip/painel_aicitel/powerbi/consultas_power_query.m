// =====================================================================
// Consultas do Power Query - Painel de Inteligência de Mercado Aicitel
// Como usar: Página Inicial > Transformar dados > Nova fonte > Consulta nula
// > Editor Avançado > cole UM bloco por consulta e dê o nome indicado.
// Antes, crie o parâmetro PastaDados (Gerenciar parâmetros > Novo):
//   Nome: PastaDados  |  Tipo: Texto  |  Valor: C:\caminho\para\powerbi\
//   (com a barra invertida no final)
// =====================================================================


// ---------- Consulta: Empresas ----------
let
    Fonte = Csv.Document(
        File.Contents(PastaDados & "fato_empresas.csv"),
        [Delimiter = ";", Encoding = 65001, QuoteStyle = QuoteStyle.Csv]
    ),
    Cabecalhos = Table.PromoteHeaders(Fonte, [PromoteAllScalars = true]),
    Tipos = Table.TransformColumnTypes(
        Cabecalhos,
        {
            {"cnpj", type text}, {"nome_fantasia", type text}, {"matriz_filial", type text},
            {"cnae_cod", type text}, {"cnae", type text}, {"atividade", type text},
            {"atividade_resumo", type text}, {"segmento", type text}, {"data_inicio", type date},
            {"ano", Int64.Type}, {"bairro", type text}, {"cep", type text}, {"regiao", type text},
            {"recente_12m", Int64.Type}, {"anterior_12m", Int64.Type}, {"concorrente", Int64.Type}
        },
        "pt-BR"
    )
in
    Tipos


// ---------- Consulta: Atividades ----------
let
    Fonte = Csv.Document(
        File.Contents(PastaDados & "dim_atividade.csv"),
        [Delimiter = ";", Encoding = 65001, QuoteStyle = QuoteStyle.Csv]
    ),
    Cabecalhos = Table.PromoteHeaders(Fonte, [PromoteAllScalars = true]),
    Tipos = Table.TransformColumnTypes(
        Cabecalhos,
        {
            {"cnae_cod", type text}, {"cnae", type text}, {"atividade", type text},
            {"atividade_resumo", type text}, {"segmento", type text},
            {"ativas_cidade", Int64.Type}, {"novas_cidade", Int64.Type}, {"anteriores_cidade", Int64.Type}
        },
        "pt-BR"
    )
in
    Tipos


// ---------- Consulta: Oportunidades ----------
let
    Fonte = Csv.Document(
        File.Contents(PastaDados & "oportunidades.csv"),
        [Delimiter = ";", Encoding = 65001, QuoteStyle = QuoteStyle.Csv]
    ),
    Cabecalhos = Table.PromoteHeaders(Fonte, [PromoteAllScalars = true]),
    Tipos = Table.TransformColumnTypes(
        Cabecalhos,
        {
            {"area", type text}, {"posicao", Int64.Type}, {"cnae_cod", type text}, {"atividade", type text},
            {"atividade_resumo", type text}, {"segmento", type text}, {"volume", Int64.Type},
            {"novas", Int64.Type}, {"anteriores", Int64.Type}, {"crescimento", type number},
            {"especializacao", type number}, {"indice", type number}
        },
        "pt-BR"
    )
in
    Tipos
